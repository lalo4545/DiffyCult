# Balances

---

<aside>
☸️

# Quick Links

<aside>
▶️

[Dashboard](https://www.notion.so/TS4-Diffy-Cult-Challenge-28ceed3eb83180f5b0f0f4e031163a32?pvs=21)

</aside>

<aside>
♾️

[Generations](https://www.notion.so/Generations-28deed3eb8318072b52ecab4abfdfe75?pvs=21)

</aside>

<aside>
⚖️

[**Balances**](Balances%2028deed3eb83180499a96f5efdb2c127e.md)

</aside>

<aside>
📜

[**Rules/Lore**](https://www.notion.so/Rules-Lore-28deed3eb83180b1965afd46279ad482?pvs=21)

</aside>

<aside>
📌

[**Extra links**](https://www.notion.so/Extra-Links-28deed3eb831804ebeb3cf77a7f9699a?pvs=21)

</aside>

</aside>

- Use this area to keep track of your loans and expenses.
    - Treat any income via the phone as donations to support the cult. They should go into here and not stay in your household account. (ie random phone calls that offer you money)
    - I personally recommend starting off with a negative amount of money and work up. Most cult leaders start below poverty line, TS4 lets you climb faster than real life lets you so this allows you to control that income a bit better.
        - I recommend about 100K as that will but gen 1 at a goal of making 150K in their lifetime in a rags to riches play.
        
    
    ---
    
    [Checkbook](Checkbook%2028eeed3eb831806f878ae84b45b834b7.csv)
    

---