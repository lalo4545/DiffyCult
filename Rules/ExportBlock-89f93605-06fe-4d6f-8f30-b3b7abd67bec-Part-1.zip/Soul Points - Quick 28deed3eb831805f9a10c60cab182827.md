# Soul Points - Quick

[Soul Points - Quick](Soul%20Points%20-%20Quick%2028ceed3eb83180e2aed7e5b1f7a20b02.csv)

[Soul Point Calculator](Soul%20Point%20Calculator%2028ceed3eb83180d7a202f2897d201e45.csv)