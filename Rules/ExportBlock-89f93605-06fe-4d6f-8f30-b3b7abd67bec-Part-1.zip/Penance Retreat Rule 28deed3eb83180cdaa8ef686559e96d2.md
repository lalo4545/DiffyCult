# Penance Retreat Rule

# Navigation Bar

<aside>
▶️

[Dashboard](https://www.notion.so/TS4-Diffy-Cult-Challenge-28ceed3eb83180f5b0f0f4e031163a32?pvs=21)

</aside>

<aside>
♾️

[Generations](https://www.notion.so/Generations-28deed3eb8318072b52ecab4abfdfe75?pvs=21)

</aside>

<aside>
⚖️

[**Balances**](https://www.notion.so/Balances-28deed3eb83180499a96f5efdb2c127e?pvs=21)

</aside>

<aside>
📜

[**Rules/Lore**](Rules%20Lore%2028deed3eb83180b1965afd46279ad482.md)

</aside>

<aside>
📌

[**Extra links**](https://www.notion.so/Extra-Links-28deed3eb831804ebeb3cf77a7f9699a?pvs=21)

</aside>

### **🕯️ Penance Retreat Rule**

When the weekly tally has  **3+ Shadow Points**,  the [Acting Cult Leader](Acting%20Cult%20Leader%2028feed3eb83180818d97fe6e86c930a1.md) enter seclusion for 24 in-game hours:

- Lock doors to keep others out.
- No phone, no TV, no social media.
- Only meditate, bathe, garden, or write.
- After 24 hours, remove all Shadow Points
    - If playing with mods:
        - add a moodlet that provides Focus
        - Fill the household needs AFTER a successful retreat

If they refuse to retreat, a fracture forms — their aura darkens (use darker clothes/makeup) until the next retreat occurs.