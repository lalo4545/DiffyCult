# Consequences

---

<aside>
☸️

# Quick Links

<aside>
▶️

[Dashboard](https://www.notion.so/TS4-Diffy-Cult-Challenge-28ceed3eb83180f5b0f0f4e031163a32?pvs=21)

</aside>

<aside>
♾️

[Generations](https://www.notion.so/Generations-28deed3eb8318072b52ecab4abfdfe75?pvs=21)

</aside>

<aside>
⚖️

[**Balances**](https://www.notion.so/Balances-28deed3eb83180499a96f5efdb2c127e?pvs=21)

</aside>

<aside>
📜

[Rules/Lore](Rules%20Lore%2028deed3eb83180b1965afd46279ad482.md)

</aside>

<aside>
📌

[**Extra links**](https://www.notion.so/Extra-Links-28deed3eb831804ebeb3cf77a7f9699a?pvs=21)

</aside>

</aside>

<aside>

<aside>

# Everyday

</aside>

[Penance Retreat Rule](Penance%20Retreat%20Rule%2028deed3eb83180cdaa8ef686559e96d2.md)

[The Great Reckoning ](The%20Great%20Reckoning%2028deed3eb83180999f4fd21e2fe9e2ad.md)

</aside>

<aside>

<aside>

# Rare Occasions

</aside>

[Week of Penance](Week%20of%20Penance%2028feed3eb8318032a9b9e26af36e48bb.md)

</aside>