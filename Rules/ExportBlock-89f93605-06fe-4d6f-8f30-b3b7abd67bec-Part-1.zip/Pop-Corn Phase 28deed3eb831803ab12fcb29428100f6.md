# Pop-Corn Phase

Enable Neighborhood Stories, Auto-Aging, and full autonomy. 

Each week spin a wheel to choose which branch to play

- [Click here](https://spinthewheel.io/wheels/jcXyOw5flCSnjiTFwdH4cz0xJmU9MQ%3D%3D) to edit your own
    
    [https://spinthewheel.app/ig880Od4ZF](https://spinthewheel.app/ig880Od4ZF)
    

**Return** to [Rules](Rules%20Lore%2028deed3eb83180b1965afd46279ad482.md)

**Return** to [Dashboard](https://www.notion.so/TS4-Diffy-Cult-Challenge-28ceed3eb83180f5b0f0f4e031163a32?pvs=21)