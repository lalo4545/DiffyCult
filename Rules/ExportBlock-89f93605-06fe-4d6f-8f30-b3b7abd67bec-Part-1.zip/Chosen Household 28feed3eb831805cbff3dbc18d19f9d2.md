# Chosen Household

---

- They now take over the Cult estate
- The “[Acting Cult Leader](Acting%20Cult%20Leader%2028feed3eb83180818d97fe6e86c930a1.md)” will abdicate when player either graduates/drops out of high school.
    - +3 SP for any groups you take over without using cheats
    - The Acting cult leader doesn’t have to abdicate until their become Elders

**Return** to [rules](Rules%20Lore%2028deed3eb83180b1965afd46279ad482.md)

**Return** to [Dashboard](https://www.notion.so/TS4-Diffy-Cult-Challenge-28ceed3eb83180f5b0f0f4e031163a32?pvs=21)