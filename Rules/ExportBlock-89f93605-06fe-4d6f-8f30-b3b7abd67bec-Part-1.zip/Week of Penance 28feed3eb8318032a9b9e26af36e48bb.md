# Week of Penance

---

- Add 3 SP
- Build a “Shrine of Return”
    - must cost more than §5, 000
    - Have acting leader meditate in there for the remainder of the sim week (minimum of 4 days)
    - Should represent the leader who has passed on
        - You cannot reuse a shrine
- Live simply for the week
    - No electronics
    - Meditation
    - Skill focus
- Have a [Choosing Ceremony](Choosing%20Ceremony%2028feed3eb83180a6956be37bac5abcd3.md)